package com.example.superherolist

data class Superhero(
var superhero:String,
var publisher:String,
var realName:String,
var photo:String
)

